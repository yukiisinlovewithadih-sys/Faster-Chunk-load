// ChunkBoost - LeviLauncher native mod.
//
// Boosts the game's chunk/worker threads (priority + fast-core affinity).
// No game memory is read or written and no signatures are used, so it does not
// depend on the Minecraft version.

#include "ThreadTuner.hpp"

#include <android/log.h>

#include <pl/Mod.hpp>

#include <filesystem>
#include <fstream>
#include <memory>
#include <mutex>
#include <sstream>
#include <string>
#include <system_error>

namespace chunkboost {

namespace {

constexpr const char *kTag = "ChunkBoost";

void logLine(const std::string &line) {
    // One logcat entry per line (logcat truncates long entries).
    std::istringstream in(line);
    std::string part;
    while (std::getline(in, part)) {
        if (part.empty()) continue;
        __android_log_print(ANDROID_LOG_INFO, kTag, "%s", part.c_str());
    }
}

std::string readAll(const std::filesystem::path &p) {
    std::ifstream in(p);
    std::ostringstream ss;
    ss << in.rdbuf();
    return ss.str();
}

}  // namespace

class ChunkBoostMod {
public:
    static ChunkBoostMod &instance() noexcept {
        static ChunkBoostMod mod;
        return mod;
    }

    bool load(pl::mod::ModContext &ctx) {
        try {
            mConfigPath = ctx.configDir() / "chunkboost.cfg";
            mReportPath = ctx.dataDir() / "thread_report.txt";

            std::error_code ec;
            std::filesystem::create_directories(ctx.configDir(), ec);
            std::filesystem::create_directories(ctx.dataDir(), ec);
            if (!std::filesystem::exists(mConfigPath, ec)) {
                std::ofstream out(mConfigPath);
                out << defaultConfigText();
            }
            logLine("ChunkBoost 1.0.0 loaded; config: " + mConfigPath.string());
        } catch (...) {
            logLine("load: unexpected error (continuing)");
        }
        return true;  // never block the game on a failure here
    }

    bool enable(pl::mod::ModContext &) {
        try {
            std::lock_guard<std::mutex> lock(mMutex);
            mTuner.reset();

            Config cfg = parseConfig(readAll(mConfigPath));
            if (!cfg.enabled) {
                logLine("enabled=0 in config; doing nothing");
                return true;
            }

            std::filesystem::path reportPath = mReportPath;
            {
                std::ofstream trunc(reportPath, std::ios::trunc);
            }
            mTuner = std::make_unique<ThreadTuner>(
                std::move(cfg), [](const std::string &m) { logLine(m); },
                [reportPath](const std::string &text) {
                    logLine(text);
                    std::ofstream out(reportPath, std::ios::app);
                    out << text << "\n";
                });
            mTuner->start();
        } catch (...) {
            logLine("enable: unexpected error (mod inactive)");
        }
        return true;
    }

    bool disable(pl::mod::ModContext &) {
        try {
            std::lock_guard<std::mutex> lock(mMutex);
            mTuner.reset();  // joins the scan thread and restores threads
        } catch (...) {
        }
        return true;
    }

    bool unload(pl::mod::ModContext &ctx) { return disable(ctx); }

private:
    ChunkBoostMod() = default;

    std::mutex mMutex;
    std::unique_ptr<ThreadTuner> mTuner;
    std::filesystem::path mConfigPath;
    std::filesystem::path mReportPath;
};

}  // namespace chunkboost

PL_REGISTER_MOD(chunkboost::ChunkBoostMod, chunkboost::ChunkBoostMod::instance())
