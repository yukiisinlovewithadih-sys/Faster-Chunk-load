#include "ThreadTuner.hpp"

#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <unistd.h>

#include <algorithm>
#include <cctype>
#include <cstdarg>
#include <cerrno>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <set>
#include <sstream>

namespace chunkboost {

namespace fs = std::filesystem;

namespace {

std::string toLower(std::string_view s) {
    std::string out(s);
    for (char &c : out) {
        c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    }
    return out;
}

std::string trim(std::string_view s) {
    std::size_t b = 0;
    std::size_t e = s.size();
    while (b < e && std::isspace(static_cast<unsigned char>(s[b]))) ++b;
    while (e > b && std::isspace(static_cast<unsigned char>(s[e - 1]))) --e;
    return std::string(s.substr(b, e - b));
}

std::vector<std::string> splitList(std::string_view s) {
    std::vector<std::string> out;
    std::size_t start = 0;
    while (start <= s.size()) {
        std::size_t comma = s.find(',', start);
        if (comma == std::string_view::npos) comma = s.size();
        std::string tok = toLower(trim(s.substr(start, comma - start)));
        if (!tok.empty()) out.push_back(std::move(tok));
        start = comma + 1;
    }
    return out;
}

bool parseBool(std::string_view v, bool fallback) {
    const std::string t = toLower(trim(v));
    if (t == "1" || t == "true" || t == "yes" || t == "on") return true;
    if (t == "0" || t == "false" || t == "no" || t == "off") return false;
    return fallback;
}

bool parseInt(std::string_view v, int &out) {
    const std::string t = trim(v);
    if (t.empty()) return false;
    char *end = nullptr;
    errno = 0;
    const long x = std::strtol(t.c_str(), &end, 10);
    if (errno != 0 || end == t.c_str() || *end != '\0') return false;
    if (x < -100000 || x > 100000) return false;
    out = static_cast<int>(x);
    return true;
}

std::string readFile(const std::string &path) {
    std::ifstream in(path);
    if (!in) return {};
    std::ostringstream ss;
    ss << in.rdbuf();
    return ss.str();
}

long long readNumber(const std::string &path) {
    const std::string s = trim(readFile(path));
    if (s.empty()) return -1;
    char *end = nullptr;
    const long long v = std::strtoll(s.c_str(), &end, 10);
    return (end == s.c_str()) ? -1 : v;
}

int currentTid() {
    return static_cast<int>(::syscall(SYS_gettid));
}

std::string fmt(const char *f, ...) __attribute__((format(printf, 1, 2)));
std::string fmt(const char *f, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, f);
    std::vsnprintf(buf, sizeof(buf), f, ap);
    va_end(ap);
    return buf;
}

std::string joinInts(const std::vector<int> &v) {
    std::string s;
    for (std::size_t i = 0; i < v.size(); ++i) {
        if (i) s += ",";
        s += std::to_string(v[i]);
    }
    return s.empty() ? "-" : s;
}

}  // namespace

// ---------------------------------------------------------------- config ----

std::vector<int> parseCoreList(std::string_view text) {
    std::set<int> out;
    std::size_t start = 0;
    while (start <= text.size()) {
        std::size_t comma = text.find(',', start);
        if (comma == std::string_view::npos) comma = text.size();
        const std::string tok = trim(text.substr(start, comma - start));
        start = comma + 1;
        if (tok.empty()) continue;
        const std::size_t dash = tok.find('-');
        int a = 0;
        int b = 0;
        if (dash == std::string::npos) {
            if (!parseInt(tok, a)) continue;
            b = a;
        } else if (!parseInt(std::string_view(tok).substr(0, dash), a) ||
                   !parseInt(std::string_view(tok).substr(dash + 1), b)) {
            continue;
        }
        if (a < 0 || b < a || b >= CPU_SETSIZE) continue;
        for (int c = a; c <= b; ++c) out.insert(c);
    }
    return std::vector<int>(out.begin(), out.end());
}

Config parseConfig(std::string_view text) {
    Config cfg;
    std::istringstream in{std::string(text)};
    std::string line;
    while (std::getline(in, line)) {
        const std::string t = trim(line);
        if (t.empty() || t[0] == '#' || t[0] == ';') continue;
        const std::size_t eq = t.find('=');
        if (eq == std::string::npos) continue;
        const std::string key = toLower(trim(std::string_view(t).substr(0, eq)));
        const std::string val = trim(std::string_view(t).substr(eq + 1));

        if (key == "enabled") {
            cfg.enabled = parseBool(val, cfg.enabled);
        } else if (key == "match") {
            cfg.match = splitList(val);
        } else if (key == "exclude") {
            cfg.exclude = splitList(val);
        } else if (key == "nice") {
            int n = 0;
            if (parseInt(val, n)) cfg.nice = std::clamp(n, -10, 19);
        } else if (key == "cores") {
            const std::string v = toLower(val);
            if (v == "auto") {
                cfg.coreMode = CoreMode::Auto;
            } else if (v == "none" || v == "off" || v.empty()) {
                cfg.coreMode = CoreMode::None;
            } else {
                cfg.cores = parseCoreList(val);
                cfg.coreMode =
                    cfg.cores.empty() ? CoreMode::None : CoreMode::Explicit;
            }
        } else if (key == "scan_interval_ms") {
            int n = 0;
            if (parseInt(val, n)) cfg.scanIntervalMs = std::clamp(n, 500, 30000);
        } else if (key == "include_main_thread") {
            cfg.includeMainThread = parseBool(val, cfg.includeMainThread);
        }
    }
    return cfg;
}

std::string defaultConfigText() {
    return
        "# ChunkBoost config. Lines starting with # are comments.\n"
        "# Edit, then disable/enable the mod (or restart the game).\n"
        "\n"
        "enabled=1\n"
        "\n"
        "# Threads whose name contains any of these words get boosted\n"
        "# (case-insensitive, comma separated). Check thread_report.txt in\n"
        "# the mod's data folder to see the real thread names on your device.\n"
        "match=worker,chunk,background\n"
        "\n"
        "# Threads containing these words are never touched.\n"
        "exclude=renderthread,glthread,egl,hwui,audio,fmod,binder,jit,signal,"
        "finalizer,reference,heaptask,perfetto,mali,kgsl,input,choreog,vsync,"
        "surface\n"
        "\n"
        "# Priority for matched threads. Lower = more important.\n"
        "# 0 = don't change. If your phone refuses negative values the mod\n"
        "# tries milder ones and logs what it got.\n"
        "nice=-4\n"
        "\n"
        "# Which CPU cores matched threads may run on:\n"
        "#   auto  = detect the fast cores\n"
        "#   none  = don't change affinity\n"
        "#   4-7   = explicit list, e.g. 4-7 or 0,1,2\n"
        "cores=auto\n"
        "\n"
        "scan_interval_ms=2000\n"
        "include_main_thread=0\n";
}

bool nameMatches(std::string_view threadName, const Config &cfg) {
    const std::string n = toLower(threadName);
    if (n.find("cb-scan") != std::string::npos) return false;  // our own thread
    for (const std::string &x : cfg.exclude) {
        if (!x.empty() && n.find(x) != std::string::npos) return false;
    }
    for (const std::string &m : cfg.match) {
        if (!m.empty() && n.find(m) != std::string::npos) return true;
    }
    return false;
}

// ------------------------------------------------------------ sys readers ---

std::vector<int> detectBigCores(const std::string &cpuRoot) {
    std::vector<std::pair<int, long long>> values;
    int total = 0;
    for (int cpu = 0; cpu < 128; ++cpu) {
        const std::string base = cpuRoot + "/cpu" + std::to_string(cpu);
        std::error_code ec;
        if (!fs::exists(base, ec)) break;
        ++total;
        long long v = readNumber(base + "/cpu_capacity");
        if (v <= 0) v = readNumber(base + "/cpufreq/cpuinfo_max_freq");
        if (v <= 0) v = readNumber(base + "/cpufreq/scaling_max_freq");
        if (v > 0) values.emplace_back(cpu, v);
    }
    if (values.size() < 2) return {};

    long long maxV = 0;
    for (const auto &p : values) maxV = std::max(maxV, p.second);
    bool allEqual = true;
    for (const auto &p : values) {
        if (p.second != maxV) allEqual = false;
    }
    if (allEqual) return {};

    std::vector<int> big;
    for (const auto &p : values) {
        if (p.second * 100 >= maxV * 97) big.push_back(p.first);
    }
    if (static_cast<int>(big.size()) >= total) return {};
    return big;
}

std::vector<ThreadInfo> listThreads(const std::string &taskDir) {
    std::vector<ThreadInfo> out;
    std::error_code ec;
    for (fs::directory_iterator it(taskDir, ec), end; !ec && it != end;
         it.increment(ec)) {
        const std::string fname = it->path().filename().string();
        int tid = 0;
        if (!parseInt(fname, tid) || tid <= 0) continue;

        ThreadInfo info;
        info.tid = tid;
        info.name = trim(readFile(it->path().string() + "/comm"));

        const std::string stat = readFile(it->path().string() + "/stat");
        const std::size_t rp = stat.rfind(')');
        if (rp != std::string::npos) {
            std::istringstream ss(stat.substr(rp + 1));
            std::string tok;
            std::vector<std::string> f;
            while (ss >> tok) f.push_back(tok);
            if (f.size() > 12) {
                info.cpuTicks = std::strtoull(f[11].c_str(), nullptr, 10) +
                                std::strtoull(f[12].c_str(), nullptr, 10);
            }
        }
        out.push_back(std::move(info));
    }
    return out;
}

// ----------------------------------------------------------------- tuner ----

ThreadTuner::ThreadTuner(Config cfg, TextFn log, TextFn report)
    : mCfg(std::move(cfg)), mLog(std::move(log)), mReport(std::move(report)) {
    mTargetNice = mCfg.nice;
}

ThreadTuner::~ThreadTuner() {
    stop();
}

void ThreadTuner::setPathsForTest(std::string taskDir, std::string cpuRoot) {
    mTaskDir = std::move(taskDir);
    mCpuRoot = std::move(cpuRoot);
}

void ThreadTuner::log(const std::string &msg) const {
    if (mLog) mLog(msg);
}

void ThreadTuner::start() {
    if (mThread.joinable()) return;
    {
        std::lock_guard<std::mutex> lock(mWaitMutex);
        mStop = false;
    }
    mThread = std::thread([this] { run(); });
}

void ThreadTuner::stop() {
    {
        std::lock_guard<std::mutex> lock(mWaitMutex);
        mStop = true;
    }
    mWaitCv.notify_all();
    if (mThread.joinable()) mThread.join();
    restoreAll();
}

std::size_t ThreadTuner::tunedCount() const {
    std::lock_guard<std::mutex> lock(mMutex);
    return mTuned.size();
}

void ThreadTuner::resolveCores() {  // mMutex held
    mCoresResolved = true;
    switch (mCfg.coreMode) {
        case CoreMode::None:
            mCores.clear();
            break;
        case CoreMode::Explicit:
            mCores = mCfg.cores;
            break;
        case CoreMode::Auto:
            mCores = detectBigCores(mCpuRoot);
            break;
    }
    log(fmt("cores to pin matched threads to: %s (mode=%s)",
            joinInts(mCores).c_str(),
            mCfg.coreMode == CoreMode::Auto
                ? "auto"
                : (mCfg.coreMode == CoreMode::None ? "none" : "explicit")));
    if (mCfg.coreMode == CoreMode::Auto && mCores.empty()) {
        log("auto core detection found no distinct fast cores; not pinning "
            "(set cores=4-7 in the config to force it)");
    }
}

void ThreadTuner::apply(int tid, const std::string &name) {  // mMutex held
    Saved s;
    s.name = name;
    std::string notes;

    // Priority: only ever make the thread MORE important, never less.
    if (mCfg.nice != 0 && !mNiceBlocked) {
        errno = 0;
        const int old = ::getpriority(PRIO_PROCESS, static_cast<id_t>(tid));
        if (!(old == -1 && errno != 0) && old > mTargetNice) {
            int t = mTargetNice;
            for (;;) {
                if (old <= t) break;
                if (::setpriority(PRIO_PROCESS, static_cast<id_t>(tid), t) ==
                    0) {
                    if (t != mTargetNice) {
                        log(fmt("phone limits priority; using nice=%d instead "
                                "of %d",
                                t, mCfg.nice));
                    }
                    mTargetNice = t;
                    s.niceChanged = true;
                    s.oldNice = old;
                    notes += fmt(" nice %d->%d", old, t);
                    break;
                }
                const int e = errno;
                if ((e == EACCES || e == EPERM) && t < -1) {
                    ++t;  // try a milder value
                    continue;
                }
                if (e == EACCES || e == EPERM) mNiceBlocked = true;
                notes += fmt(" nice FAILED (%s)", std::strerror(e));
                if (mNiceBlocked) {
                    log("setpriority is not permitted for this app; priority "
                        "will not be changed");
                }
                break;
            }
        }
    }

    // Affinity.
    if (!mCores.empty()) {
        cpu_set_t orig;
        CPU_ZERO(&orig);
        if (::sched_getaffinity(static_cast<pid_t>(tid), sizeof(orig), &orig) ==
            0) {
            cpu_set_t want;
            CPU_ZERO(&want);
            bool any = false;
            for (int c : mCores) {
                if (c >= 0 && c < CPU_SETSIZE && CPU_ISSET(c, &orig)) {
                    CPU_SET(c, &want);
                    any = true;
                }
            }
            if (any && ::sched_setaffinity(static_cast<pid_t>(tid),
                                           sizeof(want), &want) == 0) {
                s.pinned = true;
                s.oldAffinity = orig;
                notes += fmt(" pinned to %s", joinInts(mCores).c_str());
            } else {
                notes += fmt(" pin FAILED (%s)",
                             any ? std::strerror(errno) : "no allowed cores");
            }
        }
    }

    log(fmt("tuned tid=%d '%s':%s", tid, name.c_str(),
            notes.empty() ? " (nothing to change)" : notes.c_str()));
    mTuned[tid] = std::move(s);
}

int ThreadTuner::scanOnce() {
    const std::vector<ThreadInfo> threads = listThreads(mTaskDir);
    const int pid = static_cast<int>(::getpid());
    const int self = mScannerTid.load();

    std::lock_guard<std::mutex> lock(mMutex);
    if (!mCoresResolved) resolveCores();

    // Forget threads that no longer exist (their tid can be reused).
    std::set<int> alive;
    for (const ThreadInfo &t : threads) alive.insert(t.tid);
    for (auto it = mTuned.begin(); it != mTuned.end();) {
        it = alive.count(it->first) ? std::next(it) : mTuned.erase(it);
    }

    int newly = 0;
    for (const ThreadInfo &t : threads) {
        if (t.tid == self || mTuned.count(t.tid)) continue;
        if (t.tid == pid && !mCfg.includeMainThread) continue;
        if (!nameMatches(t.name, mCfg)) continue;
        apply(t.tid, t.name);
        ++newly;
    }
    return newly;
}

void ThreadTuner::restoreAll() {
    std::lock_guard<std::mutex> lock(mMutex);
    int restored = 0;
    for (auto &[tid, s] : mTuned) {
        std::error_code ec;
        if (!fs::exists(mTaskDir + "/" + std::to_string(tid), ec)) continue;
        if (s.niceChanged) {
            ::setpriority(PRIO_PROCESS, static_cast<id_t>(tid), s.oldNice);
        }
        if (s.pinned) {
            ::sched_setaffinity(static_cast<pid_t>(tid), sizeof(s.oldAffinity),
                                &s.oldAffinity);
        }
        ++restored;
    }
    if (!mTuned.empty()) log(fmt("restored %d thread(s)", restored));
    mTuned.clear();
}

std::string ThreadTuner::formatReport() const {
    std::vector<ThreadInfo> threads = listThreads(mTaskDir);
    std::sort(threads.begin(), threads.end(),
              [](const ThreadInfo &a, const ThreadInfo &b) {
                  return a.cpuTicks > b.cpuTicks;
              });

    std::set<int> tuned;
    std::vector<int> cores;
    {
        std::lock_guard<std::mutex> lock(mMutex);
        for (const auto &kv : mTuned) tuned.insert(kv.first);
        cores = mCores;
    }

    std::string out;
    out += fmt("threads=%zu tuned=%zu pin_cores=%s nice_target=%d\n",
               threads.size(), tuned.size(), joinInts(cores).c_str(),
               mCfg.nice);
    out += "   tid  cpu_ticks  nice  status    name\n";
    int shown = 0;
    for (const ThreadInfo &t : threads) {
        if (++shown > 60) break;
        errno = 0;
        int n = ::getpriority(PRIO_PROCESS, static_cast<id_t>(t.tid));
        if (n == -1 && errno != 0) n = 99;
        const char *status = "-";
        if (tuned.count(t.tid)) {
            status = "TUNED";
        } else if (nameMatches(t.name, mCfg)) {
            status = "match";
        }
        out += fmt("%6d %10llu %5d  %-8s  %s\n", t.tid, t.cpuTicks, n, status,
                   t.name.c_str());
    }
    return out;
}

void ThreadTuner::run() {
    ::prctl(PR_SET_NAME, "cb-scan", 0, 0, 0);
    mScannerTid.store(currentTid());
    log("scan thread started");

    const auto t0 = std::chrono::steady_clock::now();
    const int reportAtSec[] = {5, 30, 90, 240};
    std::size_t nextReport = 0;

    for (;;) {
        try {
            scanOnce();

            const auto elapsed =
                std::chrono::duration_cast<std::chrono::seconds>(
                    std::chrono::steady_clock::now() - t0)
                    .count();
            if (nextReport < std::size(reportAtSec) &&
                elapsed >= reportAtSec[nextReport]) {
                ++nextReport;
                if (mReport) {
                    mReport(fmt("--- t=%llds ---\n",
                                static_cast<long long>(elapsed)) +
                            formatReport());
                }
            }
        } catch (...) {
            log("scan error (ignored)");
        }

        std::unique_lock<std::mutex> lock(mWaitMutex);
        if (mWaitCv.wait_for(lock,
                             std::chrono::milliseconds(mCfg.scanIntervalMs),
                             [this] { return mStop; })) {
            break;
        }
    }
    log("scan thread stopped");
}

}  // namespace chunkboost
