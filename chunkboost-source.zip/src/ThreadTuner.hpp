#pragma once

// ChunkBoost core: finds game worker threads by *name* at runtime and raises
// their scheduling priority / pins them to the fast CPU cores.
//
// It touches no game memory and needs no offsets or signatures, so it does not
// depend on the Minecraft version. Everything here is plain Linux
// (/proc, /sys, setpriority, sched_setaffinity) and is unit-testable on a host.

#include <sched.h>

#include <atomic>
#include <condition_variable>
#include <cstddef>
#include <functional>
#include <map>
#include <mutex>
#include <string>
#include <string_view>
#include <thread>
#include <vector>

namespace chunkboost {

enum class CoreMode {
    Auto,      // detect the fast cores from /sys
    None,      // never change CPU affinity
    Explicit,  // use Config::cores
};

struct Config {
    bool enabled = true;

    // Case-insensitive substrings. A thread is tuned if its name contains any
    // `match` entry and no `exclude` entry.
    std::vector<std::string> match{"worker", "chunk", "background"};
    std::vector<std::string> exclude{
        "renderthread", "glthread", "egl",       "hwui",     "audio",
        "fmod",         "binder",   "jit",       "signal",   "finalizer",
        "reference",    "heaptask", "perfetto",  "mali",     "kgsl",
        "input",        "choreog",  "vsync",     "surface"};

    int nice = -4;  // 0 = leave priority alone. Clamped to [-10, 19].
    CoreMode coreMode = CoreMode::Auto;
    std::vector<int> cores;  // used when coreMode == Explicit

    int scanIntervalMs = 2000;  // clamped to [500, 30000]
    bool includeMainThread = false;
};

Config parseConfig(std::string_view text);
std::string defaultConfigText();

// "4-7", "0,1,2", "4-5,7" -> sorted unique list. Invalid tokens are skipped.
std::vector<int> parseCoreList(std::string_view text);

// True if the name should be tuned under `cfg`.
bool nameMatches(std::string_view threadName, const Config &cfg);

// Returns the CPUs with the highest capacity/frequency (>= 97% of the max).
// Empty if the data is unreadable or all CPUs are equal (nothing to pin to).
std::vector<int> detectBigCores(const std::string &cpuRoot =
                                    "/sys/devices/system/cpu");

struct ThreadInfo {
    int tid = 0;
    std::string name;
    unsigned long long cpuTicks = 0;  // utime + stime
};

std::vector<ThreadInfo> listThreads(const std::string &taskDir =
                                        "/proc/self/task");

class ThreadTuner {
public:
    using TextFn = std::function<void(const std::string &)>;

    ThreadTuner(Config cfg, TextFn log, TextFn report);
    ~ThreadTuner();

    ThreadTuner(const ThreadTuner &) = delete;
    ThreadTuner &operator=(const ThreadTuner &) = delete;

    void start();  // spawns the scan thread
    void stop();   // joins it and restores every changed thread

    // One scan pass. Returns the number of newly tuned threads.
    int scanOnce();

    [[nodiscard]] std::size_t tunedCount() const;
    [[nodiscard]] std::string formatReport() const;

    // Test hooks.
    void setPathsForTest(std::string taskDir, std::string cpuRoot);

private:
    struct Saved {
        std::string name;
        bool niceChanged = false;
        int oldNice = 0;
        bool pinned = false;
        cpu_set_t oldAffinity{};
    };

    void run();
    void resolveCores();
    void apply(int tid, const std::string &name);
    void restoreAll();
    void log(const std::string &msg) const;

    Config mCfg;
    TextFn mLog;
    TextFn mReport;
    std::string mTaskDir = "/proc/self/task";
    std::string mCpuRoot = "/sys/devices/system/cpu";

    mutable std::mutex mMutex;  // guards mTuned and the nice/core state
    std::map<int, Saved> mTuned;
    std::vector<int> mCores;
    bool mCoresResolved = false;
    int mTargetNice = 0;
    bool mNiceBlocked = false;

    std::mutex mWaitMutex;
    std::condition_variable mWaitCv;
    bool mStop = false;
    std::thread mThread;
    std::atomic<int> mScannerTid{0};
};

}  // namespace chunkboost
