#!/usr/bin/env python3
"""Package ChunkBoost into a LeviLaunchroid .levipack (a zip with exactly one .so).

Usage: package_levipack.py --library build/libchunkboost.so --icon assets/icon.png --output ChunkBoost.levipack
"""
import argparse
import json
import sys
import zipfile
from pathlib import Path

ENTRY = "libchunkboost.so"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--library", required=True, type=Path)
    ap.add_argument("--output", required=True, type=Path)
    ap.add_argument("--icon", type=Path, default=None)
    ap.add_argument("--manifest", type=Path, default=Path(__file__).resolve().parent.parent / "manifest.json")
    args = ap.parse_args()

    if not args.library.is_file():
        print(f"error: library not found: {args.library}", file=sys.stderr)
        return 1
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    has_icon = bool(args.icon and args.icon.is_file())
    manifest["icon"] = "icon.png" if has_icon else ""
    manifest["entry"] = ENTRY

    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.exists():
        args.output.unlink()
    with zipfile.ZipFile(args.output, "w", compression=zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifest.json", json.dumps(manifest, indent=2) + "\n")
        z.write(args.library, ENTRY)
        if has_icon:
            z.write(args.icon, "icon.png")
    print(f"Packaged {args.output} ({args.output.stat().st_size} bytes)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
