#include "../src/ThreadTuner.hpp"

#include <sys/prctl.h>
#include <sys/resource.h>
#include <sys/syscall.h>
#include <unistd.h>

#include <atomic>
#include <cassert>
#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <string>
#include <thread>
#include <vector>

using namespace chunkboost;
namespace fs = std::filesystem;

#define CHECK(cond)                                                          \
    do {                                                                     \
        if (!(cond)) {                                                       \
            std::fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__,     \
                         #cond);                                             \
            std::exit(1);                                                    \
        }                                                                    \
    } while (0)

static int myTid() { return static_cast<int>(::syscall(SYS_gettid)); }

static void writeFile(const fs::path &p, const std::string &s) {
    fs::create_directories(p.parent_path());
    std::ofstream(p) << s;
}

struct NamedThread {
    std::string name;
    std::atomic<int> tid{0};
    std::atomic<bool> stop{false};
    std::thread th;
    explicit NamedThread(std::string n) : name(std::move(n)) {
        th = std::thread([this] {
            ::prctl(PR_SET_NAME, name.c_str(), 0, 0, 0);
            tid = myTid();
            while (!stop) std::this_thread::sleep_for(std::chrono::milliseconds(5));
        });
        while (tid == 0) std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
    ~NamedThread() { stop = true; th.join(); }
};

static int niceOf(int tid) {
    errno = 0;
    return ::getpriority(PRIO_PROCESS, static_cast<id_t>(tid));
}

static void testConfig() {
    Config d = parseConfig("");
    CHECK(d.nice == -4 && d.coreMode == CoreMode::Auto && d.enabled);

    Config c = parseConfig(
        "# comment\n enabled = 0 \nmatch= Foo , bar,,\nnice=-99\n"
        "cores=4-7\nscan_interval_ms=1\ninclude_main_thread=yes\nbogus\n");
    CHECK(!c.enabled);
    CHECK((c.match == std::vector<std::string>{"foo", "bar"}));
    CHECK(c.nice == -10);
    CHECK(c.coreMode == CoreMode::Explicit);
    CHECK((c.cores == std::vector<int>{4, 5, 6, 7}));
    CHECK(c.scanIntervalMs == 500);
    CHECK(c.includeMainThread);

    CHECK(parseConfig("cores=none").coreMode == CoreMode::None);
    CHECK(parseConfig("cores=auto").coreMode == CoreMode::Auto);
    CHECK(parseConfig("cores=garbage").coreMode == CoreMode::None);
    CHECK((parseCoreList("0,2-3, 3 ,x,9-7") == std::vector<int>{0, 2, 3}));

    // The shipped default text must parse back to the built-in defaults.
    Config def;
    Config round = parseConfig(defaultConfigText());
    CHECK(round.match == def.match && round.exclude == def.exclude);
    CHECK(round.nice == def.nice && round.coreMode == def.coreMode);
    std::puts("  config OK");
}

static void testMatching() {
    Config c;
    CHECK(nameMatches("Worker Thread 3", c));
    CHECK(nameMatches("ChunkBuilder", c));
    CHECK(nameMatches("BackgroundWorke", c));
    CHECK(!nameMatches("RenderThread", c));
    CHECK(!nameMatches("GLThread worker", c));      // exclude beats match
    CHECK(!nameMatches("Binder:1234_worker", c));
    CHECK(!nameMatches("cb-scan", c));
    CHECK(!nameMatches("", c));
    std::puts("  matching OK");
}

static void testBigCores() {
    fs::path root = fs::temp_directory_path() / "cb_cpu_test";
    fs::remove_all(root);
    // 4 little (A55-like) + 4 big, capacity style.
    for (int i = 0; i < 8; ++i)
        writeFile(root / ("cpu" + std::to_string(i)) / "cpu_capacity",
                  i < 4 ? "430\n" : "1024\n");
    CHECK((detectBigCores(root.string()) == std::vector<int>{4, 5, 6, 7}));

    fs::remove_all(root);
    // Close frequencies (2.0 vs 2.2 GHz): 2.0/2.2 = 91% -> little excluded.
    for (int i = 0; i < 8; ++i)
        writeFile(root / ("cpu" + std::to_string(i)) / "cpufreq" / "cpuinfo_max_freq",
                  i < 4 ? "2000000\n" : "2200000\n");
    CHECK((detectBigCores(root.string()) == std::vector<int>{4, 5, 6, 7}));

    fs::remove_all(root);
    for (int i = 0; i < 4; ++i)
        writeFile(root / ("cpu" + std::to_string(i)) / "cpu_capacity", "1024\n");
    CHECK(detectBigCores(root.string()).empty());  // all equal

    fs::remove_all(root);
    for (int i = 0; i < 4; ++i) fs::create_directories(root / ("cpu" + std::to_string(i)));
    CHECK(detectBigCores(root.string()).empty());  // unreadable

    CHECK(detectBigCores("/nonexistent/path").empty());
    fs::remove_all(root);
    std::puts("  big-core detection OK");
}

static void testLiveTuning() {
    NamedThread w1("Worker Thread 1");
    NamedThread w2("ChunkBuilder");
    NamedThread render("RenderThread");
    NamedThread other("SomethingElse");

    std::vector<std::string> logs;
    std::mutex logMu;
    auto logFn = [&](const std::string &m) {
        std::lock_guard<std::mutex> l(logMu);
        logs.push_back(m);
    };

    Config cfg;
    cfg.nice = -3;
    cfg.coreMode = CoreMode::Explicit;
    cfg.cores = {0};

    cpu_set_t before;
    CPU_ZERO(&before);
    CHECK(::sched_getaffinity(w1.tid, sizeof(before), &before) == 0);

    {
        ThreadTuner tuner(cfg, logFn, nullptr);
        CHECK(tuner.scanOnce() == 2);
        CHECK(tuner.tunedCount() == 2);
        CHECK(tuner.scanOnce() == 0);  // idempotent

        if (::geteuid() == 0) {
            CHECK(niceOf(w1.tid) == -3);
            CHECK(niceOf(w2.tid) == -3);
        }
        CHECK(niceOf(render.tid) == 0);
        CHECK(niceOf(other.tid) == 0);

        cpu_set_t now;
        CPU_ZERO(&now);
        CHECK(::sched_getaffinity(w1.tid, sizeof(now), &now) == 0);
        CHECK(CPU_ISSET(0, &now) && CPU_COUNT(&now) == 1);
        CPU_ZERO(&now);
        CHECK(::sched_getaffinity(render.tid, sizeof(now), &now) == 0);
        CHECK(CPU_COUNT(&now) == CPU_COUNT(&before));  // untouched

        std::string rep = tuner.formatReport();
        CHECK(rep.find("TUNED") != std::string::npos);
        CHECK(rep.find("Worker Thread 1") != std::string::npos);

        // A thread that appears later is picked up.
        NamedThread late("Worker Late");
        CHECK(tuner.scanOnce() == 1);

        tuner.stop();  // restores
        CHECK(tuner.tunedCount() == 0);
        CHECK(niceOf(w1.tid) == 0);
        cpu_set_t after;
        CPU_ZERO(&after);
        CHECK(::sched_getaffinity(w1.tid, sizeof(after), &after) == 0);
        CHECK(CPU_COUNT(&after) == CPU_COUNT(&before));
    }
    std::puts("  live tuning + restore OK");
}

static void testMainThreadAndOwnThreadSkipped() {
    // The main thread is named after the test binary; make it match, and make
    // sure it is still skipped unless include_main_thread is set.
    ::prctl(PR_SET_NAME, "worker-main", 0, 0, 0);
    Config cfg;
    cfg.nice = 0;
    cfg.coreMode = CoreMode::None;
    ThreadTuner t(cfg, nullptr, nullptr);
    CHECK(t.scanOnce() == 0);
    Config cfg2 = cfg;
    cfg2.includeMainThread = true;
    ThreadTuner t2(cfg2, nullptr, nullptr);
    CHECK(t2.scanOnce() == 1);
    t2.stop();
    ::prctl(PR_SET_NAME, "tuner_test", 0, 0, 0);
    std::puts("  main-thread skip OK");
}

static void testStartStopThread() {
    NamedThread w("Worker X");
    std::atomic<int> reports{0};
    Config cfg;
    cfg.nice = 0;
    cfg.coreMode = CoreMode::None;
    cfg.scanIntervalMs = 500;
    ThreadTuner tuner(cfg, nullptr, [&](const std::string &) { ++reports; });
    tuner.start();
    for (int i = 0; i < 100 && tuner.tunedCount() == 0; ++i)
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    CHECK(tuner.tunedCount() == 1);
    auto t0 = std::chrono::steady_clock::now();
    tuner.stop();  // must return promptly, not wait a full interval
    CHECK(std::chrono::steady_clock::now() - t0 < std::chrono::milliseconds(400));
    tuner.start();  // restartable
    tuner.stop();
    std::puts("  start/stop OK");
}

static void testNiceDeniedFallback() {
    if (::geteuid() == 0) {
        std::puts("  nice-denied fallback skipped (running as root)");
        return;
    }
    NamedThread w("Worker Y");
    Config cfg;
    cfg.nice = -4;
    cfg.coreMode = CoreMode::None;
    std::vector<std::string> logs;
    ThreadTuner tuner(cfg, [&](const std::string &m) { logs.push_back(m); }, nullptr);
    CHECK(tuner.scanOnce() == 1);  // must not crash/loop when denied
    CHECK(niceOf(w.tid) == 0);
    std::puts("  nice-denied fallback OK");
}

int main() {
    ::prctl(PR_SET_NAME, "tuner_test", 0, 0, 0);
    std::puts("[chunkboost tests]");
    testConfig();
    testMatching();
    testBigCores();
    testLiveTuning();
    testMainThreadAndOwnThreadSkipped();
    testStartStopThread();
    testNiceDeniedFallback();
    std::puts("ALL TESTS PASSED");
    return 0;
}
