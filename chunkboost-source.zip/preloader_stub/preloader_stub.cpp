// Build-time stub of libpreloader.so (see the JNGS Frame Gen repo for the same
// trick). At runtime LeviLaunchroid injects the real libpreloader.so; this stub
// only makes the linker record DT_NEEDED libpreloader.so. It is NOT shipped.

#include <pl/Mod.hpp>

namespace pl::mod {

NativeMod *NativeMod::current() noexcept {
    return nullptr;
}

namespace detail {

ScopedCurrentMod::ScopedCurrentMod(NativeMod *current) noexcept
    : mPrevious(current) {}

ScopedCurrentMod::~ScopedCurrentMod() = default;

} // namespace detail

} // namespace pl::mod
