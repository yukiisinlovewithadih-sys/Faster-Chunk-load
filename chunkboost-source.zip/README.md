# ChunkBoost

LeviLauncher / LeviLaunchroid native mod that makes Minecraft's chunk worker
threads win more CPU time:

1. Finds worker threads **by name** at runtime (scans `/proc/self/task`).
2. Raises their priority (`nice`, default -4; milder values are tried if the
   phone refuses).
3. Pins them to the fast CPU cores (auto-detected from `/sys`, or set by you).

It reads and writes **no game memory** and uses **no signatures/offsets**, so it
is not tied to a Minecraft version. When disabled/unloaded it restores every
thread it changed.

## Honest expectations

- This only helps if chunk loading is waiting for CPU time. If the phone is
  thermal-throttling or already maxed on every core, expect little or nothing.
- It cannot make the game's chunk code itself faster.
- The default thread names (`worker`, `chunk`, `background`) are a **guess**.
  Check the report (below) and adjust `match=` if the real workers are named
  differently.

## Install

Build with GitHub Actions (push this repo; download the
`ChunkBoost-levipack-arm64-v8a` artifact) and import `ChunkBoost.levipack` in
LeviLauncher.

## Config and report

On first run the mod creates `config/chunkboost.cfg` in its folder (documented
inside). It also writes `data/thread_report.txt` at ~5s, 30s, 90s and 240s after
the game starts: every thread, its CPU time, priority, and whether it was tuned.
Load into a world and move around so chunks load, then check which threads burn
the most CPU. Their names are what `match=` should contain.

Logcat tag: `ChunkBoost`.

## If it does nothing / makes things worse

- `adb logcat -s ChunkBoost` shows what it matched and whether the phone allowed
  the priority/affinity changes.
- Set `cores=none` to stop pinning (pinning can hurt if the render thread is on
  the same cores), or `nice=0` to stop priority changes, or `enabled=0`.

## Tests

`g++ -std=c++20 -Isrc src/ThreadTuner.cpp tests/test_tuner.cpp -pthread -o t && ./t`
